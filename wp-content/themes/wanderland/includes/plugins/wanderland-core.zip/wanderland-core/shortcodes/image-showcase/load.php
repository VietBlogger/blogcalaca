<?php

include_once WANDERLAND_CORE_SHORTCODES_PATH . '/image-showcase/functions.php';
include_once WANDERLAND_CORE_SHORTCODES_PATH . '/image-showcase/image-showcase.php';
include_once WANDERLAND_CORE_SHORTCODES_PATH . '/image-showcase/image-showcase-item.php';