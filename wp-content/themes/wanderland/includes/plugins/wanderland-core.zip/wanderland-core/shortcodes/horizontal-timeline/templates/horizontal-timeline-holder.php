<div class="mkdf-horizontal-timeline-wrapper">
	<div class="mkdf-horizontal-timeline">
		<?php echo do_shortcode( $content ); ?>
	</div>
</div>