<?php

include_once WANDERLAND_CORE_SHORTCODES_PATH . '/progress-bar/functions.php';
include_once WANDERLAND_CORE_SHORTCODES_PATH . '/progress-bar/progress-bar.php';