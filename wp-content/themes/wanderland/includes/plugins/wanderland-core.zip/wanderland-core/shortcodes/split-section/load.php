<?php

include_once WANDERLAND_CORE_SHORTCODES_PATH . '/split-section/functions.php';
include_once WANDERLAND_CORE_SHORTCODES_PATH . '/split-section/split-section.php';