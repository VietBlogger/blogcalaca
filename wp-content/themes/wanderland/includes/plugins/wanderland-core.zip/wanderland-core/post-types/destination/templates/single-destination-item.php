<?php

get_header();

wanderland_mikado_get_title();

do_action('wanderland_mikado_action_before_main_content');

wanderland_core_get_single_destination();

get_footer();