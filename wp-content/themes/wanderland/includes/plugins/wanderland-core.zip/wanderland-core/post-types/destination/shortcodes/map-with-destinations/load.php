<?php

include_once 'helper-functions.php';
include_once 'map-with-destinations.php';
