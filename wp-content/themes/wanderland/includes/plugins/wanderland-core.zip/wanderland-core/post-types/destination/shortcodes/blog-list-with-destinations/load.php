<?php

require_once 'blog-list-with-destinations.php';
require_once 'helper-functions.php';